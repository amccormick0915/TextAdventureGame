public interface Item
{
    public double getItemPoint();
    
    public String getItemName();
    
    public void setUse(Being character);
}
